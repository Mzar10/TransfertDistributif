import java.io.*;
import java.net.*;

public class SousServeur {
    private int port;
    private int numero;

    public SousServeur(int port, int numero) {
        this.port = port;
        this.numero = numero;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Sous-serveur " + numero + " en attente de connexions sur le port " + port + "...");

            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    System.out.println("Serveur principal connecté : " + socket.getInetAddress());
                    new Thread(new FileHandler(socket)).start();
                } catch (IOException e) {
                    System.err.println("Erreur d'acceptation de connexion: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class FileHandler implements Runnable {
        
        private Socket socket;

        public FileHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
            ) {
                while (!socket.isClosed()) {
                    if (in == null || out == null || socket.isClosed()) {
                        System.err.println("Flux ou connexion non valide.");
                        return;
                    }
                    try {
                        String action = (String) in.readObject();
                        System.out.println("Action reçue : " + action);
                    
                        if ("upload".equals(action)) {
                            handleUpload(in, out);
                        } else if ("download".equals(action)) {
                            handleDownload(in, out);
                        } else if ("delete".equals(action)) {
                            handleDelete(in, out);
                        }
                    } catch (EOFException e) {
                        System.out.println("Connexion terminée par le serveur principal.");
                        break;
                    } catch (IOException | ClassNotFoundException e) {
                        System.err.println("Erreur lors de la gestion des fichiers : " + e.getMessage());
                        break;
                    }
                    
                }
            } catch (IOException e) {
                System.err.println("Erreur lors de l'I/O avec le serveur principal : " + e.getMessage());
            }
        }
        

        private void handleUpload(ObjectInputStream in, ObjectOutputStream out) {
            try {
                String fileName = (String) in.readObject();
                System.out.println("Fragment de "+fileName);
                int fragmentIndex = in.readInt();
                System.out.println("index = "+fragmentIndex);
                int bytesRead = in.readInt();
                System.out.println("Taille recue : "+bytesRead);
                

                if (bytesRead > 0) {
                    byte[] buffer = new byte[bytesRead];
                    in.readFully(buffer, 0, bytesRead);
                    // Log le contenu reçu (extrait)
                    System.out.println("Contenu reçu (extrait) : " + new String(buffer, 0, Math.min(bytesRead, 50)));
                        saveFragment(fileName, fragmentIndex, buffer);
                        System.out.println("Fragment reçu et sauvegardé avec succès.");
                } else {
                    System.err.println("Fragment vide ou invalide reçu.");
                }
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Erreur lors de la réception d'un fragment : " + e.getMessage());
            }
        }

        @SuppressWarnings("unused")
        private void handleDownload(ObjectInputStream in, ObjectOutputStream out) {
            try {
                String fileName = (String) in.readObject();
                System.out.println("Demande de fragments pour le fichier : " + fileName);

                File dir = new File("sousServeurs" + numero);
                File[] fragments = dir.listFiles((d, name) -> name.startsWith(fileName + ".part"));

                if (fragments != null && fragments.length > 0) {
                    for (File fragment : fragments) {
                        int fragmentIndex = getFragmentIndex(fragment.getName());
                        byte[] buffer = readFragment(fragment);

                        // Envoyer les informations du fragment
                        out.writeObject(fileName);
                        out.writeInt(fragmentIndex);
                        out.writeInt(buffer.length);
                        out.write(buffer);
                        out.flush();
                        System.out.println("Fragment envoyé : " + fragment.getName());
                    }
                } else {
                    System.out.println("Aucun fragment trouvé pour : " + fileName);
                }
                // Signaler la fin des fragments
                out.writeObject("END");
                out.flush();
                System.out.println("Signal de fin envoyé");
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Erreur lors de l'envoi des fragments : " + e.getMessage());
            }
        }

        @SuppressWarnings("unused")
        private void handleDelete(ObjectInputStream in, ObjectOutputStream out) {
            try {
                String fileName = (String) in.readObject();
                File dir = new File("sousServeurs" + numero);
                File[] filesToDelete = dir.listFiles((d, name) -> name.startsWith(fileName + ".part"));
            
                if (filesToDelete != null && filesToDelete.length > 0) {
                    for (File fileTodelete : filesToDelete) {
                        fileTodelete.delete();
                        System.out.println("Fragment supprimé : " + fileTodelete.getName());
                    }
                out.writeObject("DELETE_SUCCESS");
                out.flush();
                System.out.println("Suppression des fragments réussie");
                }
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Erreur lors de la suppression du fichier : " + e.getMessage());
            }
        }

        private void saveFragment(String fileName, int fragmentIndex, byte[] data) {
            try {
                File dir = new File("sousServeurs" + numero);
                if (!dir.exists()) dir.mkdirs();
        
                File fragmentFile = new File(dir, fileName + ".part" + fragmentIndex);
                try (FileOutputStream fos = new FileOutputStream(fragmentFile)) {
                    fos.write(data);
                }
                System.out.println("Fragment " + fragmentIndex + " du fichier " + fileName + " sauvegardé.");
            } catch (IOException e) {
                System.err.println("Erreur lors de la sauvegarde du fragment : " + e.getMessage());
            }
        }

        private int getFragmentIndex(String fragmentName) {
            String[] parts = fragmentName.split("\\.part");
            return Integer.parseInt(parts[1]);
        }

        private byte[] readFragment(File fragment) {
            try (FileInputStream fis = new FileInputStream(fragment)) {
                byte[] data = new byte[(int) fragment.length()];
                int bytesRead = fis.read(data);
                if (bytesRead != data.length) {
                    throw new IOException("Fragment incomplet lu : " + bytesRead + "/" + data.length);
                }
                return data;
            } catch (IOException e) {
                System.err.println("Erreur lors de la lecture du fragment : " + e.getMessage());
                return null;
            }
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java SousServeur <port> <numero>");
            return;
        }

        try {
            int port = Integer.parseInt(args[0]);
            int numero = Integer.parseInt(args[1]);
            SousServeur sousServeur = new SousServeur(port, numero);
            sousServeur.start();
        } catch (NumberFormatException e) {
            System.out.println("Le port et le numéro doivent être des nombres entiers.");
        }
    }
}