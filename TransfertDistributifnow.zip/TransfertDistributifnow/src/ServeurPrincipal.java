import java.io.*;
import java.net.*;
import java.util.*;

public class ServeurPrincipal {
    private Properties config;
    private List<Socket> sousServeurs;
    private Map<Socket, ObjectOutputStream> sousServeurStreams;
    private Map<Socket, ObjectInputStream> inSousServeurStreams;
    private List<String> uploadedFiles;

    public ServeurPrincipal() {
        config = new Properties();
        sousServeurs = new ArrayList<>();
        sousServeurStreams = new HashMap<>();
        inSousServeurStreams = new HashMap<>();
        uploadedFiles = new ArrayList<>();
        try {
            config.load(new FileInputStream("../config.txt"));
            loadUploadedFiles();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void loadUploadedFiles() {
        File file = new File("../uploadedFiles.txt");
        if (file.exists() && file.isFile()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    uploadedFiles.add(line.trim());
                }
                System.out.println("Chargement des fichiers uploadés : " + uploadedFiles);
            } catch (IOException e) {
                System.err.println("Erreur lors du chargement des fichiers uploadés : " + e.getMessage());
            }
        } else {
            System.out.println("Aucun fichier uploadedFiles.txt trouvé ou le fichier est vide.");
        }
    }
    public void start() {
        connectSousServeurs();

        try (ServerSocket serverSocket = new ServerSocket(Integer.parseInt(config.getProperty("port")))) {
            System.out.println("Serveur Principal démarré sur le port " + config.getProperty("port"));

            while (true) 
            {
                try {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Client connecté : " + clientSocket.getInetAddress());
                    new Thread(new ClientHandler(clientSocket)).start();
                } catch (IOException e) {
                    System.err.println("Erreur d'acceptation de connexion : " + e.getMessage());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void connectSousServeurs() {
        String[] sousServeursConfig = config.getProperty("sousServeurs").split(",");
        for (String sousServeurConfig : sousServeursConfig) {
            String[] parts = sousServeurConfig.split(":");
            String ip = parts[0];
            int port = Integer.parseInt(parts[1]);
    
            new Thread(() -> {
                try {
                    Socket sousServeurSocket = new Socket(ip, port);
                    sousServeurs.add(sousServeurSocket);
                    ObjectOutputStream out = new ObjectOutputStream(sousServeurSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(sousServeurSocket.getInputStream());
                    sousServeurStreams.put(sousServeurSocket, out);
                    inSousServeurStreams.put(sousServeurSocket, in);
                    System.out.println("Sous-Serveur connecté sur " + ip + ":" + port);
                } catch (IOException e) {
                    System.err.println("Erreur de connexion au sous-serveur " + ip + ":" + port + " : " + e.getMessage());
                }
            }).start();
        }
    }
    

    private void fragmentAndDistribute(File file) 
    {
        int nbSousServeurs = sousServeurs.size();
        long fileSize = file.length();
        int fragmentSize = (int) Math.ceil((double) fileSize / nbSousServeurs); // Taille fixe par fragment
    
        byte[] buffer = new byte[4096];
        int fragmentIndex = 0;
    
        try (FileInputStream fis = new FileInputStream(file)) {
            int bytesRead;
    
            while ((bytesRead = fis.read(buffer)) != -1) {
                Socket sousServeur = sousServeurs.get(fragmentIndex % nbSousServeurs);
                ObjectOutputStream out = sousServeurStreams.get(sousServeur);
                System.out.println("Envoi au sous-serveur : " + sousServeur.getRemoteSocketAddress());
                System.out.println("Nom du fichier : " + file.getName());
                System.out.println("Index du fragment : " + fragmentIndex);
                System.out.println("Taille des données : " + bytesRead);
    
                if (out == null || sousServeur.isClosed() || !sousServeur.isConnected()) {
                    System.err.println("Flux ou socket invalide pour un sous-serveur. Tentative de reconnexion...");
                    if (reconnectSousServeur(sousServeur)) {
                        out = sousServeurStreams.get(sousServeur); // Récupérer le nouveau flux après reconnexion
                    } else {
                        System.err.println("Impossible de reconnecter au sous-serveur : " + sousServeur.getRemoteSocketAddress());
                        continue; // Passer au sous-serveur suivant
                    }
                }
    
                if (out != null && bytesRead > 0) {
                    try {
                        // Envoyer les métadonnées et le fragment au sous-serveur
                        out.writeObject("upload");
                        out.writeObject(file.getName());
                        out.writeInt(fragmentIndex);
                        out.writeInt(bytesRead);
                        out.write(buffer, 0, bytesRead);
                        out.flush();
                        System.out.println("Fragment " + fragmentIndex + " envoyé. Taille : " + bytesRead);
                        System.out.println("Contenu (extrait) : " + new String(buffer, 0, Math.min(bytesRead, 50)));
                        System.out.println("fragment envoyé au sous-serveur : " + sousServeur.getRemoteSocketAddress() + ":" + sousServeur.getPort());
                     } catch (IOException e) {
                        System.err.println("Erreur lors de l'envoi du fragment au sous-serveur : " + e.getMessage());
                        System.err.println("Tentative de reconnexion au sous-serveur...");
                        if (reconnectSousServeur(sousServeur)) {
                            out = sousServeurStreams.get(sousServeur); // Récupérer le flux après reconnexion
                            try {
                                // Réessayer d'envoyer le fragment
                                out.writeObject(file.getName());
                                out.writeInt(fragmentIndex);
                                out.writeInt(bytesRead);
                                out.write(buffer, 0, bytesRead);
                                out.flush();
                            } catch (IOException e2) {
                                System.err.println("Échec de la reconnexion et de l'envoi : " + e2.getMessage());
                            }
                        } else {
                            System.err.println("Échec de la reconnexion au sous-serveur après tentative.");
                        }
                    }
                } else {
                    System.err.println("Impossible d'envoyer des données, le flux reste null après reconnexion.");
                }
    
                fragmentIndex++;
            }
        } catch (IOException e) {
            System.err.println("Erreur de lecture ou d'envoi du fichier : " + e.getMessage());
        }
    }
    
    
    private boolean reconnectSousServeur(Socket sousServeur) {
    try {
        sousServeur.close();
        Socket newSousServeur = new Socket(sousServeur.getInetAddress(), sousServeur.getPort());
        ObjectOutputStream out = new ObjectOutputStream(newSousServeur.getOutputStream());
        ObjectInputStream in = new ObjectInputStream(newSousServeur.getInputStream());
        int index = sousServeurs.indexOf(sousServeur);
        sousServeurs.set(index, newSousServeur);
        sousServeurStreams.put(newSousServeur, out);
        inSousServeurStreams.put(newSousServeur, in);
        System.out.println("Sous-serveur reconnecté : " + newSousServeur.getRemoteSocketAddress());
        return true;
    } catch (IOException e) {
        System.err.println("Échec de la reconnexion au sous-serveur : " + e.getMessage());
        return false;
    }
}
    private class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {

                while (!clientSocket.isClosed()) {
                    try {
                        String action = (String) in.readObject();
                        if ("upload".equals(action)) {
                            handleFileUpload(in, out);
                        } else if ("download".equals(action)) {
                            handleFileDownload(in, out);
                        } else if ("listFiles".equals(action)) {
                            handleListFilesRequest(out);
                        }else if ("delete".equals(action)) {
                            handleDelete(in, out);
                        }
                    } catch (IOException | ClassNotFoundException e) {
                        System.err.println("Erreur dans le gestionnaire de client : " + e.getMessage());
                        break;
                    }
                }
            } catch (IOException e) {
                System.err.println("Erreur lors de l'I/O avec le client : " + e.getMessage());
            }
        }
        private void updateUploadedFilesList() {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("../uploadedFiles.txt"))) {
                if (uploadedFiles == null) return;
                for (String fileName : uploadedFiles) {
                    writer.write(fileName);
                    writer.newLine();
                }
                System.out.println("Fichier de liste des fichiers uploadés mis à jour.");
            } catch (IOException e) {
                System.err.println("Erreur lors de l'écriture dans le fichier de liste : " + e.getMessage());
            }
        }
        
        private void handleFileUpload(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            String fileName = (String) in.readObject();
            long fileSize = in.readLong();
            File file = new File("uploads/" + fileName);
        
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalBytesRead = 0;
        
                while (totalBytesRead < fileSize && (bytesRead = in.read(buffer)) != -1) 
                {
                    fos.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                }
            }
            System.out.println("Fichier reçu : " + fileName);
            fragmentAndDistribute(file);
            file.delete();
            uploadedFiles.add(fileName);
            updateUploadedFilesList();
        }
        
        private void handleFileDownload(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
            String fileName = (String) in.readObject();
            List<byte[]> fragments = new ArrayList<>();
            System.out.println("appel de handlefiledownload");
            for (Socket sousServeur : sousServeurs) {
                if (sousServeur.isConnected() && !sousServeur.isClosed()) {
                    System.out.println("Sous-serveur connecté : " + sousServeur.getRemoteSocketAddress() + ":" + sousServeur.getPort());         
                    try {
                        ObjectOutputStream outSousServeur = sousServeurStreams.get(sousServeur);
                        ObjectInputStream inSousServeur = inSousServeurStreams.get(sousServeur);

                        if (outSousServeur == null || inSousServeur == null) {
                            // Initialisation des flux s'ils n'existent pas déjà
                            outSousServeur = new ObjectOutputStream(sousServeur.getOutputStream());
                            sousServeurStreams.put(sousServeur, outSousServeur);
                            inSousServeur = new ObjectInputStream(sousServeur.getInputStream());
                            inSousServeurStreams.put(sousServeur, inSousServeur);
                        }
            
                        System.out.println("Flux initialisés");
                        outSousServeur.writeObject("download");
                        outSousServeur.writeObject(fileName);
                        outSousServeur.flush();
                        System.out.println("Demande envoyée : " + fileName);
            
                        while (true) {
                            Object response = inSousServeur.readObject();
                            if ("END".equals(response)) {
                                System.out.println("Tous les fragments ont été reçus.");
                                break;
                            }
                            if (response instanceof String && fileName.equals(response)) {
                                int fragmentIndex = inSousServeur.readInt();
                                int fragmentSize = inSousServeur.readInt();
                                byte[] fragment = new byte[fragmentSize];
                                inSousServeur.readFully(fragment);
        
                                while (fragments.size() <= fragmentIndex) {
                                    fragments.add(null);
                                }
                                fragments.set(fragmentIndex, fragment);
                                System.out.println("Fragment reçu : index=" + fragmentIndex + ", taille=" + fragmentSize);
                            }
                        }
            
                    } catch (IOException | ClassNotFoundException e) {
                        System.err.println("Erreur de communication avec le sous-serveur :");
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("Sous-serveur déconnecté");
                }
            }
            // Reconstruction du fichier à partir des fragments
            File outputFile = new File("downloadserv/" + fileName);
            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                for (byte[] fragment : fragments) {
                    if (fragment != null) fos.write(fragment);
                }
            }
            // Envoi du fichier reconstruit au client
            long fileSize = outputFile.length();
            out.writeLong(fileSize);
            try (FileInputStream fis = new FileInputStream(outputFile)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalBytesSent = 0;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                    out.flush();
                    totalBytesSent += bytesRead;
                }
                System.out.println("Envoi terminé. Taille totale envoyée : " + totalBytesSent);
                System.out.println("Taille réelle du fichier : " + outputFile.length());
            }
            System.out.println("Fichier reconstruit et envoyé au client : " + fileName);
            outputFile.delete();
        }
        private void handleListFilesRequest(ObjectOutputStream out) throws IOException {
            synchronized (uploadedFiles) {
                out.writeObject(new ArrayList<>(uploadedFiles));
                out.flush();
            }
        }
        private void handleDelete(ObjectInputStream in, ObjectOutputStream out) throws IOException {
            try {
                String fileName = (String) in.readObject();
                if (!uploadedFiles.contains(fileName)) return;

                    // Envoi du nom du fichier à chaque sous-serveur
                    for (Socket sousServeur : sousServeurs) {
                        ObjectOutputStream outSousServeur = sousServeurStreams.get(sousServeur);
                        if (outSousServeur != null && sousServeur.isConnected()) {
                            outSousServeur.writeObject("delete");
                            outSousServeur.writeObject(fileName);
                            outSousServeur.flush();
                            System.out.println("Nom du fichier envoyé pour suppression au sous-serveur : " + sousServeur.getRemoteSocketAddress());
                        }
                    }
                    out.writeObject("DELETE_SUCCESS");
                    out.flush();
                    System.out.println("Suppression des fragments réussie");
                    uploadedFiles.remove(fileName);
                    updateUploadedFilesList();
                    
                }
                catch (IOException | ClassNotFoundException e) {
                    out.writeObject("DELETE_FAILURE");
                    out.flush();
                System.err.println("Erreur lors de la suppression du fichier : " + e.getMessage());
            }
        }
        
        
    }

    public static void main(String[] args) {
        ServeurPrincipal serveur = new ServeurPrincipal();
        serveur.start();
    }
}
