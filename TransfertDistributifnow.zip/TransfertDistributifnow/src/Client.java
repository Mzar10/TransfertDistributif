import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Client {
    private String serverAddress;
    private int serverPort;
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Client(String serverAddress, int serverPort) {
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
    }

    public void connect() throws IOException {
        try {
            socket = new Socket(serverAddress, serverPort);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            System.out.println("Connexion établie avec le serveur.");
        } catch (IOException e) {
            System.out.println("Erreur de connexion : " + e.getMessage());
            throw e; // Propager l'exception pour gérer l'erreur dans le main()
        }
    }

    public void uploadFile(String filePath) {
        if (socket == null || socket.isClosed()) {
            System.out.println("Connexion fermée. Impossible de procéder à l'upload.");
            return;
        }
        try {
            File file = new File(filePath);
            out.writeObject("upload");
            out.writeObject(file.getName());
            out.writeLong(file.length());

            byte[] buffer = new byte[4096];
            int bytesRead;
            try (FileInputStream fis = new FileInputStream(filePath)) {
                while ((bytesRead = fis.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
                out.flush();
            }
            System.out.println("Fichier " + file.getName() + " uploadé avec succès.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void downloadFile(String fileName) {
        if (socket == null || socket.isClosed()) {
            System.out.println("Connexion fermée. Impossible de procéder au téléchargement.");
            return;
        }
        try {
            System.out.println("Demande de téléchargement pour " + fileName);
            out.writeObject("download");
            out.writeObject(fileName);
            out.flush();

            long fileSize = in.readLong();
            System.out.println("Taille reçue : " + fileSize);
            File file = new File("downloads/" + fileName);
            file.getParentFile().mkdirs();

            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalBytesRead = 0;

                while (totalBytesRead < fileSize && (bytesRead = in.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                }
            }
            System.out.println("Fichier " + fileName + " téléchargé avec succès.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    public void listFiles() {
        try {
            out.writeObject("listFiles");
            out.flush();
            Object response = in.readObject();
            if (response instanceof ArrayList) {
                ArrayList<String> files = (ArrayList<String>) response;
                System.out.println("Fichiers disponibles : ");
                for (String file : files) {
                    System.out.println(file);
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur lors de la réception de la liste des fichiers : " + e.getMessage());
        }
    }
    public void deleteFile(String fileName) {
        try {
            out.writeObject("delete");
            out.writeObject(fileName);
            out.flush();

            String response = (String) in.readObject();
            if ("DELETE_SUCCESS".equals(response)) {
                System.out.println("Fichier supprimé avec succès : " + fileName);
            } else {
                System.err.println("Échec de la suppression du fichier : " + fileName);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur lors de la suppression du fichier : " + e.getMessage());
        }
    }

    public void disconnect() {
        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (socket != null && !socket.isClosed()) socket.close();
            System.out.println("Déconnexion réussie.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String serverAddress = "127.0.0.1";
        int serverPort = 12345;

        Client client = new Client(serverAddress, serverPort);

        try {
            client.connect(); // Connexion au serveur

            // Exemple d'utilisation continue

            // Attendre et continuer les opérations tant que la connexion est active
            // Pour illustration, nous allons simplement rester en boucle
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String command;
            while (true) {
                System.out.println("Entrez une commande (upload/download/exit/listFiles/delete) : ");
                command = reader.readLine().trim().toLowerCase();

                if (command.equals("upload")) {
                    System.out.print("Chemin du fichier à uploader : ");
                    String filePath = reader.readLine().trim();
                    client.uploadFile(filePath);
                } else if (command.equals("download")) {
                    System.out.print("Nom du fichier à télécharger : ");
                    String fileName = reader.readLine().trim();
                    client.downloadFile(fileName);
                } else if (command.equals("exit")) {
                    break;
                } else if (command.equals("listfiles")) {
                    client.listFiles();
                } else if (command.equals("delete")){
                    System.out.print("Nom du fichier à supprimer : ");
                    String fileName = reader.readLine().trim();
                    client.deleteFile(fileName);
                }
                 else {
                    System.out.println("Commande invalide.");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            client.disconnect(); // Ne pas déconnecter automatiquement ici
        }
    }
}
